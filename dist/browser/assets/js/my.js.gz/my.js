
// export function myTest() {
//     //alert("Work");
//     $(this).toggleClass('active');
//     console.log("Clicked menu");
//     $("#mainListDiv").toggleClass("show_list");
//     $("#mainListDiv").fadeIn();

// }


$(function() {
    $('.droopmenu-navbar').droopmenu({
        dmArrow:false
    });
});